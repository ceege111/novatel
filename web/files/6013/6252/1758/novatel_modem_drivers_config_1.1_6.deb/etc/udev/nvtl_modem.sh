#! /bin/sh

MODPROBE_CMD DRIVER_TYPE

for line in `cat /etc/udev/nvtl_modem.hardwarelist`
do
	echo "0x1410 " $line >> DRIVER_DIR/new_id
done

# determine likely modem port
export firstport=`ls /dev/nvtl/port* | head -1`
ln -sf ${firstport} /dev/modem
