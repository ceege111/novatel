#! /bin/sh

MODPROBE_CMD DRIVER_TYPE

# determine likely modem port
export firstport=`ls /dev/nvtl/port* | head -1`
ln -sf ${firstport} /dev/modem
